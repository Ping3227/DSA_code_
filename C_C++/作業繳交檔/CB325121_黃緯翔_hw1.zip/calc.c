#include <stdio.h>

int main(){
	float a,b;
	scanf("%f %f",&a,&b);
	printf("%.2f + %.2f = %.2f\n",a,b,a+b);
	printf("%.2f - %.2f = %.2f\n",a,b,a-b);
	printf("%.2f * %.2f = %.2f\n",a,b,a*b);
	printf("%.2f / %.2f = %.2f",a,b,a/b);
	return 0;
}
